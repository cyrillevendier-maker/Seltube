#!/usr/bin/env python3
"""Télécharge les polices Google utilisées par Seletube (Roboto + icônes Material Symbols)
et les range dans l'appli pour qu'elle fonctionne aussi sans Internet.
Si le téléchargement échoue, l'appli garde simplement les polices en ligne."""
import hashlib, pathlib, re, sys, urllib.request

ROOT = pathlib.Path(__file__).resolve().parent.parent
ASSETS = ROOT / "app" / "src" / "main" / "assets"
HTML = ASSETS / "selztube.html"
CSS_URL = ("https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700"
           "&family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0&display=block")
UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

def get(url):
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA}), timeout=60) as r:
        return r.read()

def main():
    try:
        css = get(CSS_URL).decode("utf-8")
        fonts = ASSETS / "fonts"
        fonts.mkdir(parents=True, exist_ok=True)
        def grab(m):
            url = m.group(1)
            name = hashlib.md5(url.encode()).hexdigest()[:12] + ".woff2"
            (fonts / name).write_bytes(get(url))
            return "url(fonts/" + name + ")"
        css = re.sub(r"url\((https://[^)]+)\)", grab, css)
        (ASSETS / "fonts.css").write_text(css, encoding="utf-8")
        html = HTML.read_text(encoding="utf-8")
        html = re.sub(r'<link rel="preconnect"[^>]*fonts\.g[^>]*>\s*', "", html)
        html = re.sub(r'<link href="https://fonts\.googleapis\.com/css2\?[^"]*" rel="stylesheet">',
                      '<link href="fonts.css" rel="stylesheet">', html)
        HTML.write_text(html, encoding="utf-8")
        print("Polices embarquées :", len(list(fonts.glob("*.woff2"))), "fichier(s)")
    except Exception as e:
        print("Avertissement : polices non embarquées (", e, ") - l'appli utilisera les polices en ligne.")
        return 0
    return 0

if __name__ == "__main__":
    sys.exit(main())
